--------------------------
--------------------------
THIRD PARTY LICENCES
--------------------------
--------------------------

This asset uses [Nethereum] and [SimpleJSON] under [The MIT License (MIT)]; see Third-Party Notices.txt file in package for details.

--------------------------
--------------------------
YOUR ETHEREUM BASE PROJECT
--------------------------
--------------------------

This project is composed with 2 main submodules:

-YourEthereumController: The basic Ethereum controller to call to perform any operation

	Available scenes:
	
		Assets\YourEthereumController\Scenes\BasicManager.unity 
		Assets\YourEthereumController\Scenes\CreateKeys.unity
		Assets\YourEthereumController\Scenes\SignTextData.unity
		Assets\YourEthereumController\Scenes\SignImageData.unity
  
-YourEthereumScreens: A collection of screens that help you to manager your ethereum account and operations

	Available scenes:
	
		Assets\YourEthereumScreens\Scenes\YourEhereumWallet.unity

-------------------------
-------------------------
YOUR ETHEREUM CONTROLLER
-------------------------
-------------------------

Thanks to this plugin you will be able to include Ethereum cryptocurreny and Blockchain signning authentication
in your games and applications.

The video tutorials make reference to Bitcoin but the methodology works almost the same way with Ethereum.

Unity Asset Store Installation Tutorial:

	https://youtu.be/k8B3y0ZCgzc

Short Introduction:

	https://youtu.be/xuF26Kd2_r8
	

TUTORIAL BASIC OPERATIONS
--------------------------

  1. IMPORT THE PACKAGE: Your Ethereum Controller
  
  2. RUN THE SCENE:

		Assets\YourEthereumController\Scenes\BasicManager.unity 
		
	 and you will be able to perform operations with Ethereum. 
	 
	 Follow the instructions on the video tutorial (time 0:15):
	 
		https://youtu.be/k8B3y0ZCgzc?t=15s
		
  3. Run the scene CreateKeys.unity to create new wallets
  
	 Follow the instructions on the last part of the video tutorial (time 0:41):
	 
		https://youtu.be/k8B3y0ZCgzc?t=41s
		
  4. Run the scenes SignTextData.unity and SignImageData.unity to sign data and document using your keys
  
	 Follow the instructions on the video tutorial (time 0:52):
	 
		https://youtu.be/k8B3y0ZCgzc?t=52s

--------------------------
--------------------------
YOUR ETHEREUM SCREENS
--------------------------
--------------------------

Thanks to this plugin you will be able to include Ethereum cryptocurreny and Blockchain signning authentication
in your games and applications.

The video tutorials make reference to Bitcoin but the methodology works almost the same way with Ethereum.

TUTORIAL INTEGRATE ETHEREUM IN YOUR APP/GAME
-----------------------------------------------

 1. GET YOUR OWN KEYS AND SET UP AT AT CLASS: EthereumController.cs

		public const string ETHERSCAN_API_KEY = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";   // Get your own key at: https://etherscan.io
        public const string INFURA_API_KEY = "YYYYYYYYYYYYYYYYY";   // Get your own key at: https://infura.io/
	
 2. RUN THE SCENE:
 
		Assets\YourEthereumScreens\Scenes\YourEhereumWallet.unity
		
 3. OR FOLLOW THE INSTRUCTIONS OF THIS VIDEO TUTORIAL TO INTEGRATE ETHEREUM IN YOUR APP/GAME:
 
	https://youtu.be/LLz3_BFcWic

 4. CREATE NEW PROJECT AND IMPORT YourEthereumController PACKAGE
 
 5. DRAG THE PREFABS TO THE SCENE:
 
		Assets\YourEthereumController\Screens\Resources\Prefabs\ScreenEthereumController.prefab
		Assets\YourEthereumController\Screens\Resources\Prefabs\LanguageController.prefab
		
 6. ADD UI\EventSystem TO THE SCENE.
 
 7. CREATE A NEW GAMEOBJECT AND ATTACH IT A SCRIPT CALLED Example.cs
 
 8. OPEN THE SCRIPT AND ADD THE CODE INSTRUCTION THAT WILL ALLOW YOU TO OPEN THE WALLET SCREEN.
 
 9. FOLLOW THE INSTRUCTIONS IN THE VIDEO TO ADD ETHEREUM FUNDS
 
 10. MODIFY THE SCRIPT AND USE THE INSTRUCTION TO OPEN THE SCREEN THAT WILL ALLOW YOU TO SEND CASH
 
 11. AFTER PERFORMING THE OPERATION YOU CAN CHECK IN TRANSACTIONS' SCREEN THAT THE OPERATION HAS BEEN DONE.

 
